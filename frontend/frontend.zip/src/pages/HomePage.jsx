import React from "react";
import { useOutletContext } from "react-router-dom";

import Header from "../components/Header";
import DotField from "../bg/DotField";
import CreateProject from "../components/CreateProject";
import SignInButton from "../components/SignInButton";

const HomePage = () => {

  const { fetchProjects, user } = useOutletContext();

  return (
    <div className="relative min-h-screen overflow-hidden">

      <div className="absolute inset-0 w-full h-full z-0">
        <DotField />
      </div>

      <div className="relative z-10">
        <Header />




        <div className="flex flex-col items-center">
          <CreateProject fetchProjects={fetchProjects} user={user} />

          {!user && <SignInButton />}
        </div>
      </div>


    </div>
  );
};

export default HomePage;